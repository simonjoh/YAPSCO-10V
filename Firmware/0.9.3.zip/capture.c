//---------------------------------------------------------------------
//	File:		capture.c
//
//	Written By:	Lawrence Glaister VE7IT
//
//  Modified by Maximilien Mousset
//
// The original code from Lawrence Glaister was made to captude 
// quadrature input from the PC. This was modified for STEP/DIR input
// with {RD0 : STEP; RD1 : DIR}
// increments/decrements command by the PC multiplier on each RD0's
// rising edge
//
//      
// 
//---------------------------------------------------------------------
//
// Revision History
//
// Aug 7 2006 --    first version Lawrence Glaister
// Aug 15 2006		added pc command pulse multiplier option
// 
//---------------------------------------------------------------------- 
#include "dspicservo.h"

extern struct PID pid;

volatile unsigned short int cmd_posn;			// current posn cmd from PC
volatile unsigned short int cmd_err;			// number of bogus encoder positions detected
volatile unsigned short int cmd_bits;	// a 4 bit number with old and new port values


/*********************************************************************
  Function:        void __attribute__((__interrupt__)) _IC1Interrupt(void)

  PreCondition:    None.
 
  Input:           None

  Output:          None.

  Side Effects:    None.

  Overview:        handles changes on IC1 pin 

  Note:            None.
********************************************************************/
void __attribute__((__interrupt__, __no_auto_psv__)) _IC1Interrupt(void)
{
    IFS0bits.IC1IF = 0;                    	// Clear IF bit
	if (PORTDbits.RD1)	// step up
		cmd_posn += pid.multiplier;
	else	// step down
		cmd_posn -= pid.multiplier;
}

/*********************************************************************
  Function:        void __attribute__((__interrupt__)) _IC2Interrupt(void)

  PreCondition:    None.
 
  Input:           None

  Output:          None.

  Side Effects:    None.

  Overview:        handles changes on IC2 pin 

  Note:            None.
********************************************************************/
void __attribute__((__no_auto_psv__, __interrupt__)) _IC2Interrupt(void)
{
    IFS0bits.IC2IF = 0;                    /* Clear IF bit */
}


/*********************************************************************
  Function:        void setup_capture(void)

  PreCondition:    None.
 
  Input:           None

  Output:          None.

  Side Effects:    None.

  Overview:        

  Note:            None.
********************************************************************/
void setup_capture(void)
{
	/* start with a clean slate in the control words */
	/* also disables IC module 1 and 2*/
	IC1CON = 0;						
	IC2CON = 0;

	/*	disable interrupts */
    IEC0bits.IC1IE = 0;
    IEC0bits.IC2IE = 0;

	/* Clean up any pending IF bits */
    IFS0bits.IC1IF = 0;             
	IFS0bits.IC2IF = 0;

	/* assign Interrupt Priority to IPC Register  (4 is default)*/
    IPC0bits.IC1IP = 0x0004;     
    IPC1bits.IC2IP = 0x0004;

    /* Config contains Clock source (0=timer 3, we dont care), 
       number of Captures per interuppt (0 = every event (not used))
       and Capture Mode (003=every rising edge)*/
	
    IC1CON = 0x0003;
    IC2CON = 0x0003;

	cmd_posn = 0;

	/*	go live... enable interrupts */
    IEC0bits.IC1IE = 1;
    IEC0bits.IC2IE = 1;
}
